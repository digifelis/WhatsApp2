<?php
//ezSQL çekirdegini dahil ediyoruz.
include_once "./ezsql/ez_sql_core.php";
 
// ezSQL veritabani bilesenini cagiriyoruz.
include_once "./ezsql/ez_sql_mysql.php";
include("vt.php");
// veritabanin ayarlarini yapiyoruz.


// ezSQL sinifini cagirarak calistirmaya basliyoruz.
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);
   $db->query("SET NAMES UTF8");
   $db->query("SET CHARACTER SET utf8");
   $db->query("SET COLLATION_CONNECTION = 'utf8_general_ci' ");  

$sonuc_liste = array();
$veriler=$db->get_row("Select * from  ".$hesk_settings['db_pfix']."ticketlar where tel='".$_GET["tel"]."' order by id desc");

if($veriler->id == 0) {
$sonuc_liste[] = '0|0|0';
} else {
$sonuc_liste[] = $veriler->durum.'|'.$veriler->t_id.'|'.$veriler->trackingid;
}

echo json_encode($sonuc_liste);
?>