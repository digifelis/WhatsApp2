<?php
$dosya_adi = $_GET["d"];
$n = "1";
$adres = $hesk_settings['site_url'];
function uzanti($dosya) {
$uzanti = pathinfo($dosya);
$uzanti = $uzanti["extension"];
return $uzanti;
}

?>
<html>
<head>
   
    <meta charset="UTF-8">

<title>Ek Dosyası No: <?php echo $n ?></title>
<?php if(uzanti($dosya_adi) == "jpg" or uzanti($dosya_adi) == "jpeg") { ?> <meta itemprop="image" content="<?php echo $adres."/attachments/".$dosya_adi; ?>"> <?php } ?>
<?php if(uzanti($dosya_adi) == "pdf") { ?> <meta itemprop="image" content="<?php echo $adres."/wp/pdf_simge.jpg"; ?>"> <?php } ?>

<meta property="og:description" content="Cevaba ek olarak verilmiş dosya">

</head>
<body>
<?php
if(uzanti($dosya_adi) == "jpg" or uzanti($dosya_adi) == "jpeg" ) {
?>
	<image src="<?php echo $adres."/attachments/".$dosya_adi ?>" height="946" width="2048">				
<?php 
} 
if(uzanti($dosya_adi) == "pdf") {

// ilk önce PDF dosyamızın FTP sunucusundaki yerini belirtiyoruz.
$file = '../attachments/' . $dosya_adi;

//Kullanıcı PDF belgesini indirmek istediği zaman hangi isimde indirsin?
// $filename değişkeninde download edilirken varsayılan dosya ismi yer alıyor. 
$filename = $dosya_adi; 

// Aşağıdaki satırda PDF uygulaması olduğunu belirtiyoruz, başka dosyalar da olabilir.
header('Content-type: application/pdf');
 
// İndirilecek dosya ismini belirtiyoruz.
header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');

// Dosya boyutunu belirtiyoruz, filesize fonksiyonu imdadımıza yetişiyor.
header('Content-Length: ' . filesize($file));
header('Accept-Ranges: bytes');
@readfile($file);

	?>
	
	<?php }  ?>
	
</body>
</html>