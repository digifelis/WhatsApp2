<?php
//ezSQL çekirdegini dahil ediyoruz.
include_once "./ezsql/ez_sql_core.php";
 
// ezSQL veritabani bilesenini cagiriyoruz.
include_once "./ezsql/ez_sql_mysql.php";
include("vt.php");

// veritabanin ayarlarini yapiyoruz.

// ezSQL sinifini cagirarak calistirmaya basliyoruz.
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);
   $db->query("SET NAMES UTF8");
   $db->query("SET CHARACTER SET utf8");
   $db->query("SET COLLATION_CONNECTION = 'utf8_general_ci' ");  



	if($_GET["islem"] == "yeni") {
		
		$db->query("insert into ".$hesk_settings['db_pfix']."ticketlar (t_id,trackingid,tel,durum) values ('".$_GET["t_id"]."' , '".$_GET["trackingid"]."' , '".$_GET["tel"]."' , '".$_GET["durum"]."') ");
		$db->query("update ".$hesk_settings['db_pfix']."tickets set replies=1 where id='".$_GET["t_id"]."' ");
	}

	
	if($_GET["islem"] == "kapat") {
		$db->query("update ".$hesk_settings['db_pfix']."ticketlar set durum = '".$_GET["durum"]."' where trackingid = '".$_GET["trackingid"]."' ");
	}
	
//$db->query("INSERT INTO mesajlar (tel,mesaj) VALUES ('".$_POST["name"]."','".$_POST["msj"]."')");



?>