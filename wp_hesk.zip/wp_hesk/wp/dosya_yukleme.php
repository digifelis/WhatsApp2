<?php
/*
error_reporting(E_ALL);
ini_set("display_errors", 1);
*/
?>

<?php
//ezSQL çekirdegini dahil ediyoruz.
include_once "./ezsql/ez_sql_core.php";
 
// ezSQL veritabani bilesenini cagiriyoruz.
include_once "./ezsql/ez_sql_mysql.php";
include_once "./vt.php";
// veritabanin ayarlarini yapiyoruz.

// ezSQL sinifini cagirarak calistirmaya basliyoruz.
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);
   $db->query("SET NAMES UTF8");
   $db->query("SET CHARACTER SET utf8");
   $db->query("SET COLLATION_CONNECTION = 'utf8_general_ci' ");  

   
   function rename_copy($targetFile, $copyPrefix = null) {
 
    $filename = basename($targetFile);
 
    $dir = pathinfo($targetFile, PATHINFO_DIRNAME);
    $name = pathinfo($targetFile, PATHINFO_FILENAME);
    $ext = pathinfo($targetFile, PATHINFO_EXTENSION);
 
    $index = 1;
    while(file_exists($dir . "/" . $filename)) {
        $filename = $name . $copyPrefix . ($index ++) . '.' . $ext;
    };
 
    return $filename;
}


$sonuc_liste = array();
$dizin = '../attachments/';

$ticket_id = $_POST["ticketid"];
$mesaj = $_POST["mesaj"];
$sonuc_liste[] = $_FILES['dosya']['name'];
if(isset($_FILES['dosya'])){
   $hata = $_FILES['dosya']['error'];
   if($hata != 0) {
      $sonuc_liste[] = 'Yüklenirken bir hata gerçekleşmiş.';
   } else {
      $boyut = $_FILES['dosya']['size'];
      if($boyut > (1024*1024*2)){
         $sonuc_liste[] = 'Dosya 2MB den büyük olamaz.';
      } else {
         $tip = $_FILES['dosya']['type'];
         $isim = $_FILES['dosya']['name'];
         $uzanti = explode('.', $isim);
         $uzanti = $uzanti[count($uzanti)-1];
		 $sonuc_liste[] = $uzanti;
         if( $uzanti != 'jpg') {
            $sonuc_liste[] = 'Yanlızca JPG yada PDF dosyaları gönderebilirsiniz.';
         } else {
			 
			$cevap = rename_copy($dizin . $_FILES['dosya']['name']);
            $dosya = $_FILES['dosya']['tmp_name'];
			$real_name = $_FILES['dosya']['name'];
            copy($dosya, $dizin . $cevap );
			$saved_name = $cevap;
            $sonuc_liste[] = 'Dosyanız upload edildi!';
         }
      }
   }
}

$db->query("insert into ".$hesk_settings['db_pfix']."attachments (ticket_id, saved_name, real_name, size) values ('".$ticket_id."' , '".$saved_name."', '".$real_name."', '".$boyut."')   ");   
$son_id = $db->insert_id;
$sonuc_liste[] = $son_id;
$eklenecek_dosya_adi = $son_id."#".$real_name."#".$saved_name.",";
$sonuc_liste[] = $ticket_id;
$bilgi = $db->get_row("select * from ".$hesk_settings['db_pfix']."tickets where trackid='".$ticket_id."' ");
if($mesaj != "") { $mesajlar = $mesaj; } else { $mesajlar = "dosya eki"; }
$sonuc_liste[] = $bilgi->id;

#$sql = "INSERT INTO `hesk_replies` (`id`, `replyto`, `name`, `message`, `dt`, `attachments`, `staffid`, `rating`, `read`, `html`) VALUES (NULL, \'1\', \'ddd\', \'sdsdfsd\', CURRENT_TIMESTAMP, NULL, \'0\', NULL, \'0\', \'0\')";
$result = $db->query("insert into ".$hesk_settings['db_pfix']."replies (id,replyto,name,message,dt,attachments) values (NULL,'".$bilgi->id."','".$bilgi->name."','".$mesajlar."',CURRENT_TIMESTAMP, '".$eklenecek_dosya_adi."') ");
#$result = $db->query("insert into hesk_replies (id,replyto, name, message, attachments,staffid,rating,read,html,dt) values (NULL, '".$bilgi->id."', '".$bilgi->name."', '".$mesajlar."', '".$eklenecek_dosya_adi."' ,'0',NULL,'0','0', CURRENT_TIMESTAMP)  ");
if($result){
  $sonuc_liste[] = $db->insert_id;
}else{
  $sonuc_liste[] = "Row could not be inserted.";
}



echo json_encode($sonuc_liste);

   


?>