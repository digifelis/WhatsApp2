<?php
//include("../hesk_settings.inc.php");

$hesk_settings['db_host']='localhost';
$hesk_settings['db_name']='';
$hesk_settings['db_user']='';
$hesk_settings['db_pass']='';
$hesk_settings['db_pfix']='wp1_';

$vt_kullanici=$hesk_settings['db_user'];
$vt_parola=$hesk_settings['db_pass'];
$vt_isim=$hesk_settings['db_name'];
$vt_sunucu=$hesk_settings['db_host'];



// veritabanin ayarlarini yapiyoruz.
/*
$vt_kullanici="destek";
$vt_parola="yzy5edu3u";
$vt_isim="zadmin_destekyeni";
$vt_sunucu="localhost";
*/
?>