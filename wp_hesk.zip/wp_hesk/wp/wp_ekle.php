 <form method = "POST" action = "">	
Telefon: <input type="text" name="name" value="">
<br>
Mesaj: <textarea name="msj" rows="5" cols="40"></textarea>
<br>
 <input type = "submit" name = "submit" value = "Submit"> 
</form>
<?php
//ezSQL çekirdegini dahil ediyoruz.
include_once "./ezsql/ez_sql_core.php";
 
// ezSQL veritabani bilesenini cagiriyoruz.
include_once "./ezsql/ez_sql_mysql.php";
include_once "./vt.php";

// veritabanin ayarlarini yapiyoruz.
// ezSQL sinifini cagirarak calistirmaya basliyoruz.
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);
   $db->query("SET NAMES UTF8");
   $db->query("SET CHARACTER SET utf8");
   $db->query("SET COLLATION_CONNECTION = 'utf8_general_ci' ");  

if($_POST) {  
$db->query("INSERT INTO ".$hesk_settings['db_pfix']."mesajlar (tel,mesaj) VALUES ('".$_POST["name"]."','".$_POST["msj"]."')");
}


?>