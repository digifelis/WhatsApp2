<?php
//ezSQL çekirdegini dahil ediyoruz.
include_once "./ezsql/ez_sql_core.php";
 
// ezSQL veritabani bilesenini cagiriyoruz.
include_once "./ezsql/ez_sql_mysql.php";
include_once "./vt.php";
// veritabanin ayarlarini yapiyoruz.
// ezSQL sinifini cagirarak calistirmaya basliyoruz.
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);
   $db->query("SET NAMES UTF8");
   $db->query("SET CHARACTER SET utf8");
   $db->query("SET COLLATION_CONNECTION = 'utf8_general_ci' ");  

$sonuc_liste = array();
$sonuclar = $db->get_results("SELECT * FROM ".$hesk_settings['db_pfix']."mesajlar where durum=0 and islem=0 limit 0 , 10");
	foreach ( $sonuclar as $sonuc )
	{
		$sonuc_liste[] = $sonuc->id.'|'.$sonuc->tel ."|". $sonuc->mesaj . "|" . $sonuc->dosya;
		$db->query("update ".$hesk_settings['db_pfix']."mesajlar set islem='".$_GET['operator']."' where id='".$sonuc->id."'");
		//echo $sonuc->tel."|".$sonuc->mesaj."<br>";
		
	}
echo json_encode($sonuc_liste);
?>