<?php
//ezSQL çekirdegini dahil ediyoruz.
include_once "./ezsql/ez_sql_core.php";
 
// ezSQL veritabani bilesenini cagiriyoruz.
include_once "./ezsql/ez_sql_mysql.php";
include_once "./vt.php";
// veritabanin ayarlarini yapiyoruz.


// ezSQL sinifini cagirarak calistirmaya basliyoruz.
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);
$db->query("SET NAMES UTF8");
$db->query("SET CHARACTER SET utf8");
$db->query("SET COLLATION_CONNECTION = 'utf8_general_ci' ");  

   
   function rename_copy($targetFile, $copyPrefix = null) {
 
    $filename = basename($targetFile);
 
    $dir = pathinfo($targetFile, PATHINFO_DIRNAME);
    $name = pathinfo($targetFile, PATHINFO_FILENAME);
    $ext = pathinfo($targetFile, PATHINFO_EXTENSION);
 
    $index = 1;
    while(file_exists($dir . "/" . $filename)) {
        $filename = $name . $copyPrefix . ($index ++) . '.' . $ext;
    };
 
    return $filename;
}


$sonuc_liste = array();
$dizin = '../attachments/';

$user_id = $_POST["user_id"];
$durum = $_POST["durum"];
$sonuc_liste[] = $_FILES['dosya']['name'];
if(isset($_FILES['dosya'])){
   $hata = $_FILES['dosya']['error'];
   if($hata != 0) {
      $sonuc_liste[] = 'Yüklenirken bir hata gerçekleşmiş.';
   } else {
      $boyut = $_FILES['dosya']['size'];
      if($boyut > (1024*1024*2)){
         $sonuc_liste[] = 'Dosya 2MB den büyük olamaz.';
      } else {
         $tip = $_FILES['dosya']['type'];
         $isim = $_FILES['dosya']['name'];
         $uzanti = explode('.', $isim);
         $uzanti = $uzanti[count($uzanti)-1];
		 $sonuc_liste[] = $uzanti;
         if( $uzanti != 'png') {
            $sonuc_liste[] = 'Yanlızca PNG dosyaları gönderebilirsiniz.';
         } else {
			 
			$cevap = $dizin . $user_id.'_karekod.png';
			unlink($cevap);
			//$cevap = rename_copy($dizin . $_FILES['dosya']['name']);
            $dosya = $_FILES['dosya']['tmp_name'];
			$real_name = $_FILES['dosya']['name'];
            copy($dosya, $dizin . $cevap );
			$saved_name = $cevap;
            $sonuc_liste[] = 'Dosyanız upload edildi!';
         }
      }
   }
}
$simdi = date('Y-m-d H:i:s');
$db->query("update ".$hesk_settings['db_pfix']."durum set karekod='".$saved_name."' , durum='".$durum."' where user_id='".$user_id."' ");
$db->query("UPDATE ".$hesk_settings['db_pfix']."durum SET zaman='".$simdi."' where user_id='".$user_id."' ");
$son_id = $db->insert_id;
$sonuc_liste[] = $son_id;

echo json_encode($sonuc_liste);

   


?>