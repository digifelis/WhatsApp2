<?php

class BaseClass {
    static function clazz() {
        return get_called_class();
    }
}