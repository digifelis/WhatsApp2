<?php


namespace BusinessLogic\Tickets;


use BusinessLogic\Attachments\AttachmentHandler;
use BusinessLogic\Security\UserContext;
use BusinessLogic\Security\UserToTicketChecker;
use DataAccess\Tickets\TicketGateway;
use PHPUnit\Framework\TestCase;

class TicketDeleterTest extends TestCase {
    /* @var $ticketDeleter TicketDeleter */
    private $ticketDeleter;

    /* @var $ticketGateway \PHPUnit_Framework_MockObject_MockObject */
    private $ticketGateway;

    /* @var $attachmentHandler \PHPUnit_Framework_MockObject_MockObject */
    private $attachmentHandler;

    /* @var $userContext UserContext */
    private $userContext;

    /* @var $heskSettings array */
    private $heskSettings;

    /* @var $userToTicketChecker \PHPUnit_Framework_MockObject_MockObject */
    private $userToTicketChecker;

    protected function setUp(): void {
        $this->userToTicketChecker = $this->createMock(UserToTicketChecker::clazz());
        $this->ticketGateway = $this->createMock(TicketGateway::clazz());
        $this->attachmentHandler = $this->createMock(AttachmentHandler::clazz());

        $this->ticketDeleter = new TicketDeleter($this->ticketGateway, $this->userToTicketChecker, $this->attachmentHandler);
    }

    function testItThrowsAnExceptionWhenTheUserDoesNotHavePermissionToDeleteTheTicket() {
        //-- Arrange
        $this->ticketGateway->method('getTicketById')->willReturn(new Ticket());
        $this->userToTicketChecker->method('isTicketAccessibleToUser')->willReturn(false);

        //-- Assert
        $this->expectException(\BaseException::clazz());
        $this->expectExceptionMessage("User does not have access to ticket 1");

        //-- Act
        $this->ticketDeleter->deleteTicket(1, $this->userContext, $this->heskSettings);
    }

    function testItDeletesAllAttachmentsForTheTicket() {
        //-- Arrange
        $ticket = new Ticket();
        $attachmentOne = new Attachment();
        $attachmentOne->id = 1;
        $attachmentTwo = new Attachment();
        $attachmentTwo->id = 2;
        $attachments = array($attachmentOne, $attachmentTwo);
        $ticket->attachments = $attachments;
        $ticket->replies = array();
        $this->ticketGateway->method('getTicketById')->willReturn($ticket);
        $this->userToTicketChecker->method('isTicketAccessibleToUser')->willReturn(true);

        //-- Assert
        $this->attachmentHandler->expects($this->exactly(2))->method('deleteAttachmentFromTicket');

        //-- Act
        $this->ticketDeleter->deleteTicket(1, $this->userContext, $this->heskSettings);
    }

    function testItDeletesAllRepliesForTheTicket() {
        //-- Arrange
        $ticket = new Ticket();
        $ticket->attachments = array();
        $ticket->replies = array();
        $ticket->id = 1;
        $this->ticketGateway->method('getTicketById')->willReturn($ticket);
        $this->userToTicketChecker->method('isTicketAccessibleToUser')->willReturn(true);

        //-- Assert
        $this->ticketGateway->expects($this->once())->method('deleteRepliesForTicket')->with(1, $this->heskSettings);

        //-- Act
        $this->ticketDeleter->deleteTicket(1, $this->userContext, $this->heskSettings);
    }

    function testItDeleteAllReplyDrafts() {
        //-- Arrange
        $ticket = new Ticket();
        $ticket->attachments = array();
        $ticket->replies = array();
        $ticket->id = 1;
        $this->ticketGateway->method('getTicketById')->willReturn($ticket);
        $this->userToTicketChecker->method('isTicketAccessibleToUser')->willReturn(true);

        //-- Assert
        $this->ticketGateway->expects($this->once())->method('deleteReplyDraftsForTicket')->with(1, $this->heskSettings);

        //-- Act
        $this->ticketDeleter->deleteTicket(1, $this->userContext, $this->heskSettings);
    }

    function testItDeletesTheTicketNotes() {
        //-- Arrange
        $ticket = new Ticket();
        $ticket->attachments = array();
        $ticket->replies = array();
        $ticket->id = 1;
        $this->ticketGateway->method('getTicketById')->willReturn($ticket);
        $this->userToTicketChecker->method('isTicketAccessibleToUser')->willReturn(true);

        //-- Assert
        $this->ticketGateway->expects($this->once())->method('deleteNotesForTicket')->with(1, $this->heskSettings);

        //-- Act
        $this->ticketDeleter->deleteTicket(1, $this->userContext, $this->heskSettings);
    }

    function testItDeletesTheTicket() {
        //-- Arrange
        $ticket = new Ticket();
        $ticket->attachments = array();
        $ticket->replies = array();
        $ticket->id = 1;
        $this->ticketGateway->method('getTicketById')->willReturn($ticket);
        $this->userToTicketChecker->method('isTicketAccessibleToUser')->willReturn(true);

        //-- Assert
        $this->ticketGateway->expects($this->once())->method('deleteTicket')->with(1, $this->heskSettings);

        //-- Act
        $this->ticketDeleter->deleteTicket(1, $this->userContext, $this->heskSettings);
    }
}
