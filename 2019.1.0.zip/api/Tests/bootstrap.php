<?php
require_once(__DIR__ . '/BusinessLogic/IntegrationTestCaseBase.php');
require_once(__DIR__ . '/../bootstrap.php');