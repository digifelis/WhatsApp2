<?php
// Copy this file as "integration_test_mfh_settings.php" to use
//-- Integration test data for Mods for HESK settings