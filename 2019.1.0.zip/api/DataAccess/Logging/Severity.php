<?php

namespace DataAccess\Logging;


class Severity extends \BaseClass {
    const DEBUG = 0;
    const INFO = 1;
    const WARNING = 2;
    const ERROR = 3;
}