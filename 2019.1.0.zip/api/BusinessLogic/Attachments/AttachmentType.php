<?php

namespace BusinessLogic\Attachments;


class AttachmentType extends \BaseClass {
    const MESSAGE = 0;
    const REPLY = 1;
}