<?php

namespace BusinessLogic\Statuses;


class Closable extends \BaseClass {
    const YES = "yes";
    const STAFF_ONLY = "sonly";
    const CUSTOMERS_ONLY = "conly";
    const NO = "no";
}