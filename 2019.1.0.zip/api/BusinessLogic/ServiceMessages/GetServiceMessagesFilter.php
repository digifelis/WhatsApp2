<?php

namespace BusinessLogic\ServiceMessages;


class GetServiceMessagesFilter {
    /* @var $includeStaffServiceMessages bool */
    public $includeStaffServiceMessages = true;

    /* @var $includeDrafts bool */
    public $includeDrafts = true;
}