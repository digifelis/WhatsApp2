<?php

namespace BusinessLogic\Calendar;


class BusinessHours {
    /* @var $dayOfWeek int */
    public $dayOfWeek;

    /* @var $startTime string */
    public $startTime;

    /* @var $endTime string */
    public $endTime;
}