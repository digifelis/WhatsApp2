<?php
/**
 * Created by PhpStorm.
 * User: mkoch
 * Date: 2/20/2017
 * Time: 10:03 PM
 */

namespace BusinessLogic\Tickets;


class StageTicket extends Ticket {
    //-- Nothing here, just an indicator that it is a StageTicket and not a regular Ticket
}