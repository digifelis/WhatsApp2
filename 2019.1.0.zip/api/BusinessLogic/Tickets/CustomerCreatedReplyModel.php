<?php

namespace BusinessLogic\Tickets;


class CustomerCreatedReplyModel {
    public $id;
    public $ticketId;
    public $replierName;
    public $message;
    public $dateCreated;
    public $html;
}