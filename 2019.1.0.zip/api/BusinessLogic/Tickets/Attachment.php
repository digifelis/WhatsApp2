<?php

namespace BusinessLogic\Tickets;


class Attachment extends \BaseClass {
    /**
     * @var int
     */
    public $id;

    /**
     * @var string
     */
    public $fileName;

    /**
     * @var string
     */
    public $savedName;
}