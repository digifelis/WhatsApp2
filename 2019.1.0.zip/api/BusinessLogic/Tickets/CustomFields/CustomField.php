<?php
namespace BusinessLogic\Tickets\CustomFields;


class CustomField {
    /* @var $id int */
    public $id;

    /* @var $name string */
    public $name;

    /* @var $type string */
    public $type;

    /* @var $properties array */
    public $properties;
}