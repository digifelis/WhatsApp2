<?php

namespace BusinessLogic\Tickets;


class AuditTrailEntityType extends \BaseClass {
    const TICKET = 'TICKET';
    const CALENDAR_EVENT = 'CALENDAR_EVENT';
}