<?php

namespace BusinessLogic\Tickets;


class TicketGatewayGeneratedFields extends \BaseClass {
    public $id;
    public $dateCreated;
    public $dateModified;
}