<?php

namespace BusinessLogic\Navigation;


class Direction extends \BaseClass {
    const UP = 'up';
    const DOWN = 'down';
}