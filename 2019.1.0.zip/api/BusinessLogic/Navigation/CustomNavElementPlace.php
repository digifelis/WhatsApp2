<?php

namespace BusinessLogic\Navigation;


class CustomNavElementPlace extends \BaseClass {
    const HOMEPAGE_BLOCK = 1;
    const CUSTOMER_NAVIGATION = 2;
    const ADMIN_NAVIGATION = 3;
}