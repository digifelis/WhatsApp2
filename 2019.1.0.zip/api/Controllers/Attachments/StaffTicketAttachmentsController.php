<?php

namespace Controllers\Attachments;


use BusinessLogic\Attachments\AttachmentHandler;
use BusinessLogic\Attachments\AttachmentRetriever;
use BusinessLogic\Attachments\CreateAttachmentForTicketModel;
use BusinessLogic\Exceptions\ApiFriendlyException;
use BusinessLogic\Helpers;
use BusinessLogic\Security\UserToTicketChecker;
use Controllers\JsonRetriever;

class StaffTicketAttachmentsController extends \BaseClass {
    function get($ticketId, $attachmentId) {
        global $hesk_settings, $applicationContext, $userContext;

        $this->verifyAttachmentsAreEnabled($hesk_settings);

        /* @var $attachmentRetriever AttachmentRetriever */
        $attachmentRetriever = $applicationContext->get(AttachmentRetriever::clazz());

        $contents = $attachmentRetriever->getAttachmentContentsForTicket($ticketId, $attachmentId, $userContext, $hesk_settings);

        output(array('contents' => $contents));
    }

    private function verifyAttachmentsAreEnabled($heskSettings) {
        if (!$heskSettings['attachments']['use']) {
            throw new ApiFriendlyException('Attachments are disabled on this server', 'Attachments Disabled', 404);
        }
    }

    function post($ticketId) {
        global $hesk_settings, $applicationContext, $userContext;

        $this->verifyAttachmentsAreEnabled($hesk_settings);

        /* @var $attachmentHandler AttachmentHandler */
        $attachmentHandler = $applicationContext->get(AttachmentHandler::clazz());

        $createAttachmentForTicketModel = $this->createModel(JsonRetriever::getJsonData(), $ticketId);

        $createdAttachment = $attachmentHandler->createAttachmentForTicket(
            $createAttachmentForTicketModel, $userContext, $hesk_settings);

        return output($createdAttachment, 201);
    }

    private function createModel($json, $ticketId) {
        $model = new CreateAttachmentForTicketModel();
        $model->attachmentContents = Helpers::safeArrayGet($json, 'data');
        $model->displayName = Helpers::safeArrayGet($json, 'displayName');
        $model->isEditing = Helpers::safeArrayGet($json, 'isEditing');
        $model->ticketId = $ticketId;

        return $model;
    }

    function delete($ticketId, $attachmentId) {
        global $applicationContext, $hesk_settings, $userContext;

        /* @var $attachmentHandler AttachmentHandler */
        $attachmentHandler = $applicationContext->get(AttachmentHandler::clazz());

        $attachmentHandler->deleteAttachmentFromTicket($ticketId, $attachmentId, $userContext, $hesk_settings);

        return http_response_code(204);
    }
}