var mfhLang = {
    text: function(key) {
        return $('#lang_' + key).text();
    },
    html: function(key) {
        return $('#lang_' + key).html()
    }
};