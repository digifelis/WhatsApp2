<?php

// Define the current build
define('MODS_FOR_HESK_BUILD', 53);
