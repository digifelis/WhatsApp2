<!-- Here you can insert additional links and dropdowns to the top navigation bar on the client-side of the help desk.  You can insert anything you like.
     Some example code has been included below, and is commented out so it will not appear on the page.  It is recommended to copy & paste the code you
     want to use so you still have the samples included. You can use PHP code as well, by using the <?php //and ?> tags
-->




<!-- Use this block of code for a single link (such as the "Home" link) -->
<!-- <li><a href="link_here">Text to Display</a></li> -->

<!-- Use this block of code for a dropdown menu (such as the "ticket" dropdown) -->
<!-- <li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown Text<b class="caret"></b></a>
    <ul class="dropdown-menu">
        <li><a href="#">Text to Display</a></li>
        <li><a href="#">Text to Display</a></li>
    </ul>
</li> -->

<!-- Your custom nav elements should begin down here -->
